<?php
$server_name = "localhost";
$username = "root";
$password = "";
$database_name = "exercise";

$conn = mysqli_connect($server_name, $username, $password, $database_name);

//STORE - Insert clicked
if (isset($_POST['insertStore'])) {
    $storeidStore = $_POST['storeidStore'];
    $staffidStore = $_POST['staffidStore'];
    $addressidStore = $_POST['addressidStore'];

    $check = "SELECT * FROM store WHERE store_id = $storeidStore";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {
        $queryUpdate = "UPDATE store SET manager_staff_id = $staffidStore, address_id = $addressidStore, last_update = now() WHERE store_id = $storeidStore";

        if (mysqli_query($conn, $queryUpdate)) {

            header('location:store.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        $queryInsert = "INSERT INTO store VALUES (($storeidStore),($staffidStore),($addressidStore),now())";

        if (mysqli_query($conn, $queryInsert)) {
            $showSuccFlag = 1;
            header('location:store.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    }

    $mysqli_close($conn);
}

//STORE - Delete Clicked
if (isset($_POST['deleteStore'])) {
    $storeid = $_POST['storeidStoreDelete'];

    $check = "SELECT * FROM store WHERE store_id = $storeid";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {

        $queryDelete = "DELETE FROM store WHERE store_id = $storeid";

        if (mysqli_query($conn, $queryDelete)) {
            $showSuccFlag = 1;
            header('location:store.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        echo "This Store ID doesn't exist in the database.";
    }

    $mysqli_close($conn);
}


//STAFF - button clicked
if (isset($_POST['insertStaff'])) {
    $staffid = $_POST['staffidStaff'];
    $fname = $_POST['fnameStaff'];
    $lname = $_POST['lnameStaff'];
    $addressid = $_POST['addressidStaff'];
    $picture = $_POST['pictureStaff'];
    $email = $_POST['emailStaff'];
    $storeid = $_POST['storeidStaff'];
    $active = $_POST['activeStaff'];
    $username = $_POST['usernameStaff'];
    $password = $_POST['passwordStaff'];

    $check = "SELECT * FROM staff WHERE staff_id = $staffid";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {
        $queryUpdate = "UPDATE `staff` SET `first_name`='$fname',`last_name`='$lname',`address_id`=$addressid,`email`='$email',`store_id`=$storeid,`active`=$active,`username`='$username',`password`='$password',`last_update`= now() WHERE staff_id = $staffid";

        if (mysqli_query($conn, $queryUpdate)) {
            $showSuccFlag = 1;
            header('location:staff.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        $queryInsert = "INSERT INTO `staff`(`staff_id`, `first_name`, `last_name`, `address_id`, `picture`, `email`, `store_id`, `active`, `username`, `password`, `last_update`) VALUES ($staffid,'$fname','$lname',$addressid,'$picture','$email', $storeid, $active,'$username','$password',now())";

        if (mysqli_query($conn, $queryInsert)) {
            $showSuccFlag = 1;
            header('location:staff.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    }

    $mysqli_close($conn);
}

//STAFF - Delete Clicked
if(isset($_POST['deleteStaff']))
{
    $staffid = $_POST['staffidStaffDelete'];

    $check = "SELECT * FROM staff WHERE staff_id = $staffid";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {

        $queryDelete = "DELETE FROM staff WHERE staff_id = $staffid";

        if (mysqli_query($conn, $queryDelete)) {
            $showSuccFlag = 1;
            header('location:staff.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        echo "This Store ID doesn't exist in the database.";
    }

    $mysqli_close($conn);

}


//RENTAL - insert clicked
if (isset($_POST['insertRental'])) {
    $rentalid = $_POST['rentalidRental'];
    $rentaldate = $_POST['rentaldateRental'];
    $inventoryid = $_POST['inventoryidRental'];
    $customerid = $_POST['customeridRental'];
    $returndate = $_POST['returndateRental'];
    $staffid = $_POST['staffidRental'];


    $check = "SELECT * FROM rental WHERE rental_id = $rentalid";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {
        $queryUpdate = "UPDATE `rental` SET rental_date= STR_TO_DATE('$rentaldate','%Y-%m-%d %H:%i:%s'), inventory_id=$inventoryid, customer_id=$customerid,
			return_date=STR_TO_DATE('$renturndate','%Y-%m-%d %H:%i:%s'), last_update=now() WHERE rental_id = $rentalid";

        if (mysqli_query($conn, $queryUpdate)) {
            $showSuccFlag = 1;
            header('location:rental.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        $queryInsert = "INSERT INTO `rental`(`rental_id`, `rental_date`, `inventory_id`, `customer_id`, `return_date`, `staff_id`, `last_update`) VALUES ($rentalid, STR_TO_DATE('$rentaldate','%Y-%m-%d %H:%i:%s'), $inventoryid, $customerid, STR_TO_DATE('$returndate','%Y-%m-%d %H:%i:%s'), $staffid, now())";

        if (mysqli_query($conn, $queryInsert)) {
            $showSuccFlag = 1;
            header('location:rental.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    }

    $mysqli_close($conn);
}

//RENTAL - Delete Clicked
if(isset($_POST['deleteRental']))
{
    $rentalid = $_POST['rentalidRentalDelete'];

    $check = "SELECT * FROM rental WHERE rental_id = $rentalid";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {

        $queryDelete = "DELETE FROM rental WHERE rental_id = $rentalid";

        if (mysqli_query($conn, $queryDelete)) {
            $showSuccFlag = 1;
            header('location:rental.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        echo "This Store ID doesn't exist in the database.";
    }

    $mysqli_close($conn);

}

//PAYMENT - button clicked
if (isset($_POST['insertPayment'])) {
    $paymentid = $_POST['paymentidPayment'];
    $customerid = $_POST['customeridPayment'];
    $staffid = $_POST['staffidPayment'];
    $rentalid = $_POST['rentalidPayment'];
    $amount = $_POST['amountPayment'];
    $paymentdate = $_POST['paymentdatePayment'];

    $check = "SELECT * FROM payment WHERE payment_id = $paymentid";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {
        $queryUpdate = "UPDATE `payment` SET customer_id=$customerid, staff_id=$staffid, rental_id=$rentalid, amount=$amount, payment_date=STR_TO_DATE('$paymentdate','%Y-%m-%d %H:%i:%s'), last_update=now() WHERE `payment_id`=$paymentid";

        if (mysqli_query($conn, $queryUpdate)) {
            $showSuccFlag = 1;
            header('location:payment.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        $queryInsert = "INSERT INTO `payment`(`payment_id`, `customer_id`, `staff_id`, `rental_id`, `amount`, `payment_date`, `last_update`) VALUES ($paymentid,$customerid,$staffid,$rentalid,$amount,STR_TO_DATE('$paymentdate','%Y-%m-%d %H:%i:%s'),now())";

        if (mysqli_query($conn, $queryInsert)) {
            $showSuccFlag = 1;
            header('location:payment.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    }

    $mysqli_close($conn);
}

//PAYMENT - Delete Clicked
if(isset($_POST['deletePayment']))
{
    $paymentid = $_POST['paymentidPaymentDelete'];

    $check = "SELECT * FROM payment WHERE payment_id = $paymentid";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {

        $queryDelete = "DELETE FROM payment WHERE payment_id = $paymentid";

        if (mysqli_query($conn, $queryDelete)) {
            $showSuccFlag = 1;
            header('location:payment.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        echo "This Store ID doesn't exist in the database.";
    }

    $mysqli_close($conn);

}

//LANGUAGE - button clicked
if (isset($_POST['insertLanguage'])) {
    $languageid = $_POST['languageidLanguage'];
    $name = $_POST['nameLanguage'];

    $check = "SELECT * FROM language WHERE language_id = $languageid";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {
        $queryUpdate = "UPDATE language SET name='$name',last_update=now() WHERE language_id = $languageid";

        if (mysqli_query($conn, $queryUpdate)) {
            $showSuccFlag = 1;
            header('location:language.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        $queryInsert = "INSERT INTO language VALUES ($languageid,'$name',now())";

        if (mysqli_query($conn, $queryInsert)) {
            $showSuccFlag = 1;
            header('location:language.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    }

    $mysqli_close($conn);
}

//LANGUAGE - Delete Clicked
if(isset($_POST['deleteLanguage']))
{
    $languageid = $_POST['languageidLanguageDelete'];

    $check = "SELECT * FROM language WHERE language_id = $languageid";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {

        $queryDelete = "DELETE FROM language WHERE language_id = $languageid";

        if (mysqli_query($conn, $queryDelete)) {
            $showSuccFlag = 1;
            header('location:language.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        echo "This Store ID doesn't exist in the database.";
    }

    $mysqli_close($conn);

}

//INVENTORY - button clicked
if (isset($_POST['insertInventory'])) {
    $inventoryid = $_POST['inventoryidInventory'];
    $filmid = $_POST['filmidInventory'];
    $storeid = $_POST['storeidInventory'];

    $check = "SELECT * FROM inventory WHERE inventory_id = $inventoryid";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {
        $queryUpdate = "UPDATE inventory SET film_id=$filmid, store_id=$storeid, last_update=now() WHERE inventory_id = $inventoryid";

        if (mysqli_query($conn, $queryUpdate)) {
            $showSuccFlag = 1;
            header('location:inventory.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        $queryInsert = "INSERT INTO inventory VALUES ($inventoryid,$filmid,$storeid,now())";

        if (mysqli_query($conn, $queryInsert)) {
            $showSuccFlag = 1;
            header('location:inventory.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    }

    $mysqli_close($conn);
}

//INVENTORY - Delete Clicked
if(isset($_POST['deleteInventory']))
{
    $inventoryid = $_POST['inventoryidInventoryDelete'];

    $check = "SELECT * FROM inventory WHERE inventory_id = $inventoryid";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {

        $queryDelete = "DELETE FROM inventory WHERE inventory_id = $inventoryid";

        if (mysqli_query($conn, $queryDelete)) {
            $showSuccFlag = 1;
            header('location:inventory.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        echo "This Store ID doesn't exist in the database.";
    }

    $mysqli_close($conn);

}


//FILM_TEXT - button clicked
if (isset($_POST['insertFilmtext'])) {
    $filmid = $_POST['filmidFilmtext'];
    $title = $_POST['titleFilmtext'];
    $description = $_POST['descriptionFilmtext'];

    $check = "SELECT * FROM film_text WHERE film_id = $filmid";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {
        $queryUpdate = "UPDATE film_text SET title='$title', description='$description' WHERE film_id = $filmid";

        if (mysqli_query($conn, $queryUpdate)) {
            $showSuccFlag = 1;
            header('location:filmtext.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        $queryInsert = "INSERT INTO film_text VALUES ($filmid,'$title','$description')";

        if (mysqli_query($conn, $queryInsert)) {
            $showSuccFlag = 1;
            header('location:filmtext.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    }

    $mysqli_close($conn);
}

//FILM_TEXT - Delete Clicked
if(isset($_POST['deleteFilmtext']))
{
    $filmid = $_POST['filmidFilmtextDelete'];

    $check = "SELECT * FROM film_text WHERE film_id = $filmid";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {

        $queryDelete = "DELETE FROM film_text WHERE film_id = $filmid";

        if (mysqli_query($conn, $queryDelete)) {
            $showSuccFlag = 1;
            header('location:filmtext.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        echo "This Store ID doesn't exist in the database.";
    }

    $mysqli_close($conn);

}

//FILM_CATEGORY - button clicked
if (isset($_POST['insertFilmcategory'])) {
    $filmid = $_POST['filmidFilmcategory'];
    $categoryid = $_POST['categoryidFilmcategory'];

    $check = "SELECT * FROM film_category WHERE film_id = $filmid";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {
        $queryUpdate = "UPDATE `film_category` SET `category_id`=$categoryid,`last_update`=now() WHERE `film_id`=$filmid";

        if (mysqli_query($conn, $queryUpdate)) {
            $showSuccFlag = 1;
            header('location:filmcategory.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        $queryInsert = "INSERT INTO film_category VALUES ($filmid,$categoryid,now())";

        if (mysqli_query($conn, $queryInsert)) {
            $showSuccFlag = 1;
            header('location:filmcategory.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    }

    $mysqli_close($conn);
}

//FILM_CATEGORY - Delete Clicked
if(isset($_POST['deleteFilmcategory']))
{
    $filmid = $_POST['filmidFilmcategoryDelete'];

    $check = "SELECT * FROM film_category WHERE film_id = $filmid";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {

        $queryDelete = "DELETE FROM film_category WHERE film_id = $filmid";

        if (mysqli_query($conn, $queryDelete)) {
            $showSuccFlag = 1;
            header('location:filmcategory.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        echo "This Store ID doesn't exist in the database.";
    }

    $mysqli_close($conn);

}

//Actor - Insert clicked
if (isset($_POST['insertActor'])) {
    $actoridActor = $_POST['actoridActor'];
    $firstnameActor = $_POST['firstnameActor'];
    $lastnameActor = $_POST['lastnameActor'];

    $check = "SELECT * FROM actor WHERE actor_id = $actoridActor";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {
        $queryUpdate = "UPDATE actor SET first_name = '$firstnameActor', last_name = '$lastnameActor', last_update = now() WHERE actor_id = $actoridActor";
        if (mysqli_query($conn, $queryUpdate)) {
            echo "Insert Sucessful.";
            header("location: actor.php");
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }

        $mysqli_close($conn);
    } else {
        $queryInsert = "INSERT INTO actor VALUES (($actoridActor),('$firstnameActor'),('$lastnameActor'),now())";

        if (mysqli_query($conn, $queryInsert)) {
            echo "Insert Sucessful.";
            header("location: actor.php");
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    }

    $mysqli_close($conn);
}

//Actor - Delete Clicked
if (isset($_POST['deleteActor'])) {
    $actoridActor = $_POST['actoridActor'];

    $check = "SELECT * FROM actor WHERE actor_id = $actoridActor";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {

        $queryDelete = "DELETE FROM actor WHERE actor_id = $actoridActor";

        if (mysqli_query($conn, $queryDelete)) {
            $showSuccFlag = 1;
            header('location:actor.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        echo "This Actor ID doesn't exist in the database.";
    }

    $mysqli_close($conn);
}

//Address - Insert clicked
if (isset($_POST['insertAddress'])) {
    $addressidAddress = $_POST['addressidAddress'];
    $addressAddress = $_POST['addressAddress'];
    $address2Address = $_POST['address2Address'];
    $districtAddress = $_POST['districtAddress'];
    $cityidAddress = $_POST['cityidAddress'];
    $postalcodeAddress = $_POST['postalcodeAddress'];
    $phoneAddress = $_POST['phoneAddress'];

    $check = "SELECT * FROM address WHERE address_id = $addressidAddress";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {
        $queryUpdate = "UPDATE address SET address = '$addressAddress', address2 = '$address2Address', district = '$districtAddress', city_id = $cityidAddress, postal_code = $postalcodeAddress, phone = $phoneAddress, last_update = now() WHERE address_id = $addressidAddress";
        if (mysqli_query($conn, $queryUpdate)) {
            echo "Insert Sucessful.";
            header("location: address.php");
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        $queryInsert = "INSERT INTO address VALUES (($addressidAddress),('$addressAddress'),('$address2Address'),('$districtAddress'),($cityidAddress),($postalcodeAddress),($phoneAddress),now())";

        if (mysqli_query($conn, $queryInsert)) {
            echo "Insert Sucessful.";
            header("location: address.php");
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    }

    $mysqli_close($conn);
}

//Address - Delete Clicked
if (isset($_POST['deleteAddress'])) {
    $addressidAddress = $_POST['addressidAddress'];

    $check = "SELECT * FROM address WHERE address_id = $addressidAddress";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {

        $queryDelete = "DELETE FROM address WHERE address_id = $addressidAddress";

        if (mysqli_query($conn, $queryDelete)) {
            $showSuccFlag = 1;
            header('location:address.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        echo "This Address ID doesn't exist in the database.";
    }

    $mysqli_close($conn);
}

//Category - Insert clicked
if (isset($_POST['insertCategory'])) {
    $categoryidCategory = $_POST['categoryidCategory'];
    $nameCategory = $_POST['nameCategory'];

    $check = "SELECT * FROM category WHERE category_id = $categoryidCategory";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {
        $queryUpdate = "UPDATE category SET name = '$nameCategory', last_update = now() WHERE category_id = $categoryidCategory";
        if (mysqli_query($conn, $queryUpdate)) {
            echo "Insert Sucessful.";
            header("location: category.php");
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        $queryInsert = "INSERT INTO category VALUES (($categoryidCategory),('$nameCategory'), now())";

        if (mysqli_query($conn, $queryInsert)) {
            echo "Insert Sucessful.";
            header("location: category.php");
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    }

    $mysqli_close($conn);
}

//Category - Delete Clicked
if (isset($_POST['deleteCategory'])) {
    $categoryidCategory = $_POST['categoryidCategory'];

    $check = "SELECT * FROM category WHERE category_id = $categoryidCategory";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {

        $queryDelete = "DELETE FROM category WHERE category_id = $categoryidCategory";

        if (mysqli_query($conn, $queryDelete)) {
            $showSuccFlag = 1;
            header('location:category.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        echo "This Category ID doesn't exist in the database.";
    }

    $mysqli_close($conn);
}

//City - Insert clicked
if (isset($_POST['insertCity'])) {
    $cityidCity = $_POST['cityidCity'];
    $cityCity = $_POST['cityCity'];
    $countryidCity = $_POST['countryidCity'];

    $check = "SELECT * FROM city WHERE city_id = $cityidCity";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {
        $queryUpdate = "UPDATE city SET city = '$cityCity', country_id = $countryidCity, last_update = now() WHERE city_id = $cityidCity";
        if (mysqli_query($conn, $queryUpdate)) {
            echo "Insert Sucessful.";
            header("location: city.php");
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        $queryInsert = "INSERT INTO city VALUES (($cityidCity),('$cityCity'),($countryidCity),now())";

        if (mysqli_query($conn, $queryInsert)) {
            echo "Insert Sucessful.";
            header("location: city.php");
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    }

    $mysqli_close($conn);
}

//City - Delete Clicked
if (isset($_POST['deleteCity'])) {
    $cityidCity = $_POST['cityidCity'];

    $check = "SELECT * FROM city WHERE city_id = $cityidCity";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {

        $queryDelete = "DELETE FROM city WHERE city_id = $cityidCity";

        if (mysqli_query($conn, $queryDelete)) {
            $showSuccFlag = 1;
            header('location:city.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        echo "This City ID doesn't exist in the database.";
    }

    $mysqli_close($conn);
}

//Country - Insert clicked
if (isset($_POST['insertCountry'])) {
    $countryidCountry = $_POST['countryidCountry'];
    $countryCountry = $_POST['countryCountry'];

    $check = "SELECT * FROM country WHERE country_id = $countryidCountry";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {
        $queryUpdate = "UPDATE country SET country = '$countryCountry', last_update = now() WHERE country_id = $countryidCountry";
        if (mysqli_query($conn, $queryUpdate)) {
            echo "Insert Sucessful.";
            header("location: country.php");
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        $queryInsert = "INSERT INTO country VALUES (($countryidCountry),('$countryCountry'),now())";

        if (mysqli_query($conn, $queryInsert)) {
            echo "Insert Sucessful.";
            header("location: country.php");
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    }

    $mysqli_close($conn);
}

//Country - Delete Clicked
if (isset($_POST['deleteCountry'])) {
    $countryidCountry = $_POST['countryidCountry'];

    $check = "SELECT * FROM country WHERE country_id = $countryidCountry";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {

        $queryDelete = "DELETE FROM country WHERE country_id = $countryidCountry";

        if (mysqli_query($conn, $queryDelete)) {
            $showSuccFlag = 1;
            header('location:country.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        echo "This Country ID doesn't exist in the database.";
    }

    $mysqli_close($conn);
}

//Customer - Insert clicked
if (isset($_POST['insertCustomer'])) {
    $customeridCustomer = $_POST['customeridCustomer'];
    $storeidCustomer = $_POST['storeidCustomer'];
    $firstnameCustomer = $_POST['firstnameCustomer'];
    $lastnameCustomer = $_POST['lastnameCustomer'];
    $emailCustomer = $_POST['emailCustomer'];
    $addressidCustomer = $_POST['addressidCustomer'];
    $activeCustomer = $_POST['activeCustomer'];
    $createdateCustomer = $_POST['createdateCustomer'];

    $check = "SELECT * FROM customer WHERE customer_id = $customeridCustomer";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {
        $queryUpdate = "UPDATE customer SET store_id = $storeidCustomer, first_name = '$firstnameCustomer', last_name = '$lastnameCustomer', email = '$emailCustomer', address_id = $addressidCustomer, active = $activeCustomer, create_date = STR_TO_DATE('$createdateCustomer','%Y-%m-%d %H:%i:%s'), last_update = now() WHERE customer_id = $customeridCustomer";
        if (mysqli_query($conn, $queryUpdate)) {
            echo "Insert Sucessful.";
            header("location: customer.php");
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        $queryInsert = "INSERT INTO customer VALUES (($customeridCustomer),($storeidCustomer),('$firstnameCustomer'),('$lastnameCustomer'),('$emailCustomer'),($addressidCustomer),($activeCustomer), STR_TO_DATE('$createdateCustomer','%Y-%m-%d %H:%i:%s'), now())";

        if (mysqli_query($conn, $queryInsert)) {
            echo "Insert Sucessful.";
            header("location: customer.php");
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    }

    $mysqli_close($conn);
}

//Customer - Delete Clicked
if (isset($_POST['deleteCustomer'])) {
    $customeridCustomer = $_POST['customeridCustomer'];

    $check = "SELECT * FROM customer WHERE customer_id = $customeridCustomer";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {

        $queryDelete = "DELETE FROM customer WHERE customer_id = $customeridCustomer";

        if (mysqli_query($conn, $queryDelete)) {
            $showSuccFlag = 1;
            header('location:customer.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        echo "This Customer ID doesn't exist in the database.";
    }

    $mysqli_close($conn);
}

//Film - Insert clicked
if (isset($_POST['insertFilm'])) {
    $filmidFilm = $_POST['filmidFilm'];
    $titleFilm = $_POST['titleFilm'];
    $descriptionFilm = $_POST['descriptionFilm'];
    $releaseyearFilm = $_POST['releaseyearFilm'];
    $languageidFilm = $_POST['languageidFilm'];
    $originallanguageidFilm = $_POST['originallanguageidFilm'];
    $rentaldurationFilm = $_POST['rentaldurationFilm'];
    $rentalrateFilm = $_POST['rentalrateFilm'];
    $lengthFilm = $_POST['lengthFilm'];
    $replacementcostFilm = $_POST['replacementcostFilm'];
    $ratingFilm = $_POST['ratingFilm'];
    $specialfeaturesFilm = $_POST['specialfeaturesFilm'];

    $check = "SELECT * FROM film WHERE film_id = $filmidFilm";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {
        $queryUpdate = "UPDATE film SET title = '$titleFilm', description = '$descriptionFilm', release_year = STR_TO_DATE('$releaseyearFilm','%Y'), language_id = $languageidFilm, original_language_id = $originallanguageidFilm, rental_duration = $rentaldurationFilm, rental_rate = $rentalrateFilm, length = $lengthFilm, replacement_cost = $replacementcostFilm, rating = '$ratingFilm', special_features = '$specialfeaturesFilm', last_update = now() WHERE film_id = $filmidFilm";
        if (mysqli_query($conn, $queryUpdate)) {
            echo "Insert Sucessful.";
            header("location: film.php");
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        $queryInsert = "INSERT INTO film VALUES (($filmidFilm),('$titleFilm'),('$descriptionFilm'), STR_TO_DATE('$releaseyearFilm','%Y'),($languageidFilm),($originallanguageidFilm),($rentaldurationFilm), ($rentalrateFilm), ($lengthFilm), ($replacementcostFilm), ('$ratingFilm'), ('$specialfeaturesFilm'), now())";

        if (mysqli_query($conn, $queryInsert)) {
            echo "Insert Sucessful.";
            header("location: film.php");
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    }

    $mysqli_close($conn);
}

//Film - Delete Clicked
if (isset($_POST['deleteFilm'])) {
    $filmidFilm = $_POST['filmidFilm'];

    $check = "SELECT * FROM film WHERE film_id = $filmidFilm";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {

        $queryDelete = "DELETE FROM film WHERE film_id = $filmidFilm";

        if (mysqli_query($conn, $queryDelete)) {
            $showSuccFlag = 1;
            header('location:film.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        echo "This Film ID doesn't exist in the database.";
    }

    $mysqli_close($conn);
}

//Film_actor - Insert clicked
if (isset($_POST['insertFilmactor'])) {
    $actoridFilmactor = $_POST['actoridFilmactor'];
    $filmidFilmactor = $_POST['filmidFilmactor'];

    $check = "SELECT * FROM film_actor WHERE film_id = $filmidFilmactor";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {
        $queryUpdate = "UPDATE film_actor SET actor_id = $actoridFilmactor, last_update = now() WHERE film_id = $filmidFilmactor";
        if (mysqli_query($conn, $queryUpdate)) {
            echo "Insert Sucessful.";
            header("location: filmactor.php");
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        $queryInsert = "INSERT INTO film_actor VALUES (($actoridFilmactor),($filmidFilmactor), now())";

        if (mysqli_query($conn, $queryInsert)) {
            echo "Insert Sucessful.";
            header("location: filmactor.php");
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    }

    $mysqli_close($conn);
}

//Film_actor - Delete Clicked
if (isset($_POST['deleteFilmactor'])) {
    $actoridFilmactor = $_POST['actoridFilmactor'];

    $check = "SELECT * FROM film_actor WHERE film_id = $filmidFilmactor";
    $result = mysqli_query($conn, $check);
    $count = mysqli_num_rows($result);

    if ($count >= 1) {

        $queryDelete = "DELETE FROM film_actor WHERE film_id = $filmidFilmactor";

        if (mysqli_query($conn, $queryDelete)) {
            $showSuccFlag = 1;
            header('location:filmactor.php');
        } else {
            echo "Error:" . "" . mysqli_error($conn);
        }
    } else {
        echo "This Actor ID doesn't exist in the database.";
    }

    $mysqli_close($conn);
}
