<?php include('server.php'); ?>
<?php $currentPage = 'City'; ?>
<?php include('includes/head.php'); ?>

<?php
$conn = mysqli_connect("localhost", "root", "", "exercise");
if (isset($_POST['search'])) {
    $searchKey = $_POST['searchkey'];
    if ($searchKey >= 1) {
        $sql = "SELECT * FROM `city` WHERE city_id = $searchKey";
        $result = mysqli_query($conn, $sql);
    }

    if ($searchKey == 0 || $searchKey == "") {
        $sql = "SELECT * FROM `city`";
        $result = mysqli_query($conn, $sql);
    }
} else {
    //$searchKey = $_POST['searchkey'];
    //if ($searchKey == 0 || $searchKey == "") {
    $sql = "SELECT * FROM `city` LIMIT 750";
    $result = mysqli_query($conn, $sql);
    //}
}
?>

<body class="d-flex flex-column h-100">

    <?php include('includes/navbar.php'); ?>

    <main class="flex-shrink-0">
        <div class="container-sm rounded bg-light p-3" style="margin-top: 5em">
            <div class="row g-3 justify-content-between align-items-center">
                <div class="col">
                    <button class="btn btn-primary me-2" type="button" data-bs-toggle="collapse" data-bs-target="#insertUpdateCity" aria-expanded="false" aria-controls="insertUpdateCity">Insert/update entry</button>
                    <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#deleteCityID" aria-expanded="false" aria-controls="deleteCityID">Delete entry</button>
                </div>
                <form class="col-lg-3 col-md-5" action="" method="POST">
                    <div class="input-group">
                        <input type="number" class="form-control" name="searchkey" id="searchkey" placeholder="City ID" aria-describedby="searchBtn" min="1">
                        <button type="submit" class="btn btn-outline-primary" name="search" id="searchBtn" type="button" id="searchBtn">Search</button>
                    </div>
                </form>
            </div>

            <form class="collapse" id="insertUpdateCity" action="server.php" method="POST">
                <hr>
                <h5 class="mt-3 mb-3">Insert/update entry in <strong><?= $currentPage ?></strong>:</h5>
                <div class="row g-3">
                    <div class="col form-floating mb-3">
                        <input type="number" class="form-control" name="cityidCity" id="cityidCity" min="1" placeholder="1" required>
                        <label for="cityidCity">&ensp;City ID</label>
                    </div>

                    <div class="col form-floating mb-3">
                        <input type="text" class="form-control" name="cityCity" id="cityCity" placeholder="a" required>
                        <label for="cityCity">&ensp;City Name</label>
                    </div>

                    <div class="col form-floating mb-3">
                        <input type="number" class="form-control" name="countryidCity" id="countryidCity" min="1" placeholder="1" required>
                        <label for="countryidCity">&ensp;Country ID</label>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary" name="insertCity">Submit</button>
            </form>

            <form class="collapse" id="deleteCityID" action="server.php" method="POST">
                <hr>
                <h5 class="mt-3 mb-3">Delete entry from <strong><?= $currentPage ?></strong>:</h5>
                <div class="row g-3">
                    <div class="col form-floating mb-3">
                        <input type="number" class="form-control" name="cityidCity" id="cityidCity" min="1" placeholder="1" required>
                        <label for="cityidCity">&ensp;City ID</label>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary" name="deleteCity">Submit</button>
            </form>
        </div>

        <table class="table table-striped table-hover table-responsive caption-top container-sm p-3 mt-3">
            <caption>
                <h3 class="text-primary">Entries in <strong><?= $currentPage ?></strong>:</h3>
            </caption>
            <thead>
                <tr>
                    <th scope="col">City ID &ensp;<span class="material-icons align-bottom me-2 text-warning">vpn_key</span></th>
                    <th scope="col">City Name</th>
                    <th scope="col">Country ID &ensp;<span class="material-icons align-bottom me-2 text-muted">vpn_key</span></th>
                    <th scope="col">Last Updated</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_object($result)) : ?>
                    <tr>
                        <th scope="row"><?php echo $row->city_id ?></th>
                        <td><?php echo $row->city ?></td>
                        <td><?php echo $row->country_id ?></td>
                        <td><?php echo $row->last_update ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

    </main>

    <?php include('includes/footer.php'); ?>
