<header>
    <nav class="navbar navbar-expand navbar-dark fixed-top bg-primary">
        <div class="container-fluid">

            <a class="navbar-brand" href="/movies"><span class="material-icons align-text-top">theaters</span> Fantastic Movies</a>

            <ul class="navbar-nav me-auto mb-2 mb-md-0">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle active" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Tables</a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <?php
                        $urls = array(
                            'Actor' => '/movies/actor.php',
                            'Address' => '/movies/address.php',
                            'Category' => '/movies/category.php',
                            'City' => '/movies/city.php',
                            'Country' => '/movies/country.php',
                            'Customer' => '/movies/customer.php',
                            'Film' => '/movies/film.php',
                            'Film Actor' => '/movies/filmactor.php',
                            'Film Category' => '/movies/filmcategory.php',
                            'Film Text' => '/movies/filmtext.php',
                            'Inventory' => '/movies/inventory.php',
                            'Language' => '/movies/language.php',
                            'Payment' => '/movies/payment.php',
                            'Rental' => '/movies/rental.php',
                            'Staff' => '/movies/staff.php',
                            'Store' => '/movies/store.php',
                        );

                        foreach ($urls as $name => $url) {
                            echo '
                            <li>
                                <a class="dropdown-item' . (($currentPage === $name) ? ' active" aria-current="page"' : '"') . ' href="' . $url . '">' . $name . '</a>
                            </li>
                            ';
                        }
                        ?>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</header>
