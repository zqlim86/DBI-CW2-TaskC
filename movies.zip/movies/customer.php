<?php include('server.php'); ?>
<?php $currentPage = 'Customer'; ?>
<?php include('includes/head.php'); ?>

<?php
$conn = mysqli_connect("localhost", "root", "", "exercise");
if (isset($_POST['search'])) {
    $searchKey = $_POST['searchkey'];
    if ($searchKey >= 1) {
        $sql = "SELECT * FROM customer WHERE customer_id = $searchKey";
        $result = mysqli_query($conn, $sql);
    }

    if ($searchKey == 0 || $searchKey == "") {
        $sql = "SELECT * FROM customer";
        $result = mysqli_query($conn, $sql);
    }
} else {
    //$searchKey = $_POST['searchkey'];
    //if ($searchKey == 0 || $searchKey == "") {
    $sql = "SELECT * FROM customer LIMIT 750";
    $result = mysqli_query($conn, $sql);
    //}
}
?>

<body class="d-flex flex-column h-100">

    <?php include('includes/navbar.php'); ?>

    <main class="flex-shrink-0">
        <div class="container-sm rounded bg-light p-3" style="margin-top: 5em">
            <div class="row g-3 justify-content-between align-items-center">
                <div class="col">
                    <button class="btn btn-primary me-2" type="button" data-bs-toggle="collapse" data-bs-target="#insertUpdateCustomer" aria-expanded="false" aria-controls="insertUpdateCustomer">Insert/update entry</button>
                    <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#deleteCustomerID" aria-expanded="false" aria-controls="deleteCustomerID">Delete entry</button>
                </div>
                <form class="col-lg-3 col-md-5" action="" method="POST">
                    <div class="input-group">
                        <input type="number" class="form-control" name="searchkey" id="searchkey" placeholder="Customer ID" aria-describedby="searchBtn" min="1">
                        <button type="submit" class="btn btn-outline-primary" name="search" id="searchBtn" type="button" id="searchBtn">Search</button>
                    </div>
                </form>
            </div>

            <form class="collapse" id="insertUpdateCustomer" action="server.php" method="POST">
                <hr>
                <h5 class="mt-3 mb-3">Insert/update entry in <strong><?= $currentPage ?></strong>:</h5>
                <div class="row g-3">
                    <div class="col form-floating mb-3">
                        <input type="number" class="form-control" name="customeridCustomer" id="customeridCustomer" min="1" placeholder="1" required>
                        <label for="customeridCustomer">&ensp;Customer ID</label>
                    </div>

                    <div class="col form-floating mb-3">
                        <input type="number" class="form-control" name="storeidCustomer" id="storeidCustomer" min="1" placeholder="1" required>
                        <label for="storeidCustomer">&ensp;Store ID</label>
                    </div>

                    <div class="col form-floating mb-3">
                        <input type="number" class="form-control" name="addressidCustomer" id="addressidCustomer" min="1" placeholder="1" required>
                        <label for="addressidCustomer">&ensp;Address ID</label>
                    </div>
                </div>
                <div class="row g-3">
                    <div class="col-2 form-floating mb-3">
                        <input type="text" class="form-control" name="firstnameCustomer" id="firstnameCustomer" placeholder="a" required>
                        <label for="firstnameCustomer">&ensp;First Name</label>
                    </div>
                    <div class="col-2 form-floating mb-3">
                        <input type="text" class="form-control" name="lastnameCustomer" id="lastnameCustomer" placeholder="a" required>
                        <label for="lastnameCustomer">&ensp;Last Name</label>
                    </div>
                    <div class="col form-floating mb-3">
                        <input type="mail" class="form-control" name="emailCustomer" id="emailCustomer" placeholder="a" required>
                        <label for="emailCustomer">&ensp;Email</label>
                    </div>
                    <div class="col-3 form-floating mb-3">
                        <input type="text" class="form-control" name="createdateCustomer" id="createdateCustomer" placeholder="a" required>
                        <label for="createdateCustomer">&ensp;Creation Date</label>
                    </div>
                </div>
                <div class="row g-3">
                    <div class="col form-check mb-3 mx-2">
                        <input class="form-check-input mb-3" type="hidden" name="activeCustomer" id="activeCustomer" value="0" />
                        <input class="form-check-input mb-3" type="checkbox" name="activeCustomer" id="activeCustomer" value="1" checked>
                        <label class="form-check-label mb-3" for="activeCustomer">Active</label>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary" name="insertCustomer">Submit</button>
            </form>

            <form class="collapse" id="deleteCustomerID" action="server.php" method="POST">
                <hr>
                <h5 class="mt-3 mb-3">Delete entry from <strong><?= $currentPage ?></strong>:</h5>
                <div class="row g-3">
                    <div class="col form-floating mb-3">
                        <input type="number" class="form-control" name="customeridCustomer" id="customeridCustomer" min="1" placeholder="1" required>
                        <label for="customeridCustomer">&ensp;Customer ID</label>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary" name="deleteCustomer">Submit</button>
            </form>
        </div>

        <table class="table table-striped table-hover table-responsive caption-top container-sm p-3 mt-3">
            <caption>
                <h3 class="text-primary">Entries in <strong><?= $currentPage ?></strong>:</h3>
            </caption>
            <thead>
                <tr>
                    <th scope="col">Customer ID &ensp;<span class="material-icons align-bottom me-2 text-warning">vpn_key</span></th>
                    <th scope="col">Store ID &ensp;<span class="material-icons align-bottom me-2 text-muted">vpn_key</span></th>
                    <th scope="col">First Name</th>
                    <th scope="col">Last Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Address ID &ensp;<span class="material-icons align-bottom me-2 text-muted">vpn_key</span></th>
                    <th scope="col">Active</th>
                    <th scope="col">Creation Date</th>
                    <th scope="col">Last Updated</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_object($result)) : ?>
                    <tr>
                        <th scope="row"><?php echo $row->customer_id ?></th>
                        <td><?php echo $row->store_id ?></td>
                        <td><?php echo $row->first_name ?></td>
                        <td><?php echo $row->last_name ?></td>
                        <td><?php echo $row->email ?></td>
                        <td><?php echo $row->address_id ?></td>
                        <td><?php echo $row->active ?></td>
                        <td><?php echo $row->create_date ?></td>
                        <td><?php echo $row->last_update ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

    </main>

    <?php include('includes/footer.php'); ?>