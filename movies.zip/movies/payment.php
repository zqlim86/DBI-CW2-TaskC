<?php include('server.php'); ?>
<?php $currentPage = 'Payment'; ?>
<?php include('includes/head.php'); ?>

<?php
$conn = mysqli_connect("localhost", "root", "", "exercise");
if (isset($_POST['search'])) {
    $searchKey = $_POST['searchkey'];
    if ($searchKey >= 1) {
        $sql = "SELECT * FROM payment WHERE payment_id = $searchKey";
        $result = mysqli_query($conn, $sql);
    }

    if ($searchKey == 0 || $searchKey == "") {
        $sql = "SELECT * FROM payment";
        $result = mysqli_query($conn, $sql);
    }
} else {
    //$searchKey = $_POST['searchkey'];
    //if ($searchKey == 0 || $searchKey == "") {
    $sql = "SELECT * FROM payment LIMIT 750";
    $result = mysqli_query($conn, $sql);
    //}
}
?>

<body class="d-flex flex-column h-100">

    <?php include('includes/navbar.php'); ?>

    <main class="flex-shrink-0">
        <div class="container-sm rounded bg-light p-3" style="margin-top: 5em">
            <div class="row g-3 justify-content-between align-items-center">
                <div class="col">
                    <button class="btn btn-primary me-2" type="button" data-bs-toggle="collapse" data-bs-target="#insertUpdatePayment" aria-expanded="false" aria-controls="insertUpdatePayment">Insert/update entry</button>
                    <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#deletePaymentID" aria-expanded="false" aria-controls="deletePaymentID">Delete entry</button>
                </div>
                <form class="col-lg-3 col-md-5" action="" method="POST">
                    <div class="input-group">
                        <input type="number" class="form-control" name="searchkey" id="searchkey" placeholder="Payment ID" aria-describedby="searchBtn" min="1">
                        <button type="submit" class="btn btn-outline-primary" name="search" id="searchBtn" type="button" id="searchBtn">Search</button>
                    </div>
                </form>
            </div>

            <form class="collapse" id="insertUpdatePayment" action="server.php" method="POST">
                <hr>
                <h5 class="mt-3 mb-3">Insert/update entry in <strong><?= $currentPage ?></strong>:</h5>
                <div class="row g-3">
                    <div class="col form-floating mb-3">
                        <input type="number" class="form-control" name="paymentidPayment" id="paymentidPayment" min="1" placeholder="1" required>
                        <label for="paymentidPayment">&ensp;Payment ID</label>
                    </div>

                    <div class="col form-floating mb-3">
                        <input type="number" class="form-control" name="customeridPayment" id="customeridPayment" min="1" placeholder="1">
                        <label for="customeridPayment">&ensp;Customer ID</label>
                    </div>

                    <div class="col form-floating mb-3">
                        <input type="number" class="form-control" name="staffidPayment" id="staffidPayment" min="1" placeholder="1">
                        <label for="staffidPayment">&ensp;Staff ID</label>
                    </div>

                    <div class="col form-floating mb-3">
                        <input type="number" class="form-control" name="rentalidPayment" id="rentalidPayment" min="1" placeholder="1">
                        <label for="rentalidPayment">&ensp;Rental ID</label>
                    </div>
                </div>
                <div class="row g-3">
                    <div class="col form-floating mb-3">
                        <input type="number" class="form-control" name="amountPayment" id="amountPayment" min="0" step="0.01" placeholder="1">
                        <label for="amountPayment">&ensp;Amount</label>
                    </div>
                    <div class="col form-floating mb-3">
                        <input type="text" class="form-control" name="paymentdatePayment" id="paymentdatePayment" placeholder="a">
                        <label for="paymentdatePayment">&ensp;Payment Date</label>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary" name="insertPayment">Submit</button>
            </form>

            <form class="collapse" id="deletePaymentID" action="server.php" method="POST">
                <hr>
                <h5 class="mt-3 mb-3">Delete entry from <strong><?= $currentPage ?></strong>:</h5>
                <div class="row g-3">
                    <div class="col form-floating mb-3">
                        <input type="number" class="form-control" name="paymentidPaymentDelete" id="paymentidPaymentDelete" min="1" placeholder="1" required>
                        <label for="paymentidPaymentDelete">&ensp;Payment ID</label>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary" name="deletePayment">Submit</button>
            </form>
        </div>

        <table class="table table-striped table-hover table-responsive caption-top container-sm p-3 mt-3">
            <caption>
                <h3 class="text-primary">Entries in <strong><?= $currentPage ?></strong>:</h3>
            </caption>
            <thead>
                <tr>
                    <th scope="col">Payment ID &ensp;<span class="material-icons align-bottom me-2 text-warning">vpn_key</span></th>
                    <th scope="col">Customer ID &ensp;<span class="material-icons align-bottom me-2 text-muted">vpn_key</span></th>
                    <th scope="col">Staff ID &ensp;<span class="material-icons align-bottom me-2 text-muted">vpn_key</span></th>
                    <th scope="col">Rental ID &ensp;<span class="material-icons align-bottom me-2 text-muted">vpn_key</span></th>
                    <th scope="col">Amount</th>
                    <th scope="col">Payment Date</th>
                    <th scope="col">Last Updated</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_object($result)) : ?>
                    <tr>
                        <th scope="row"><?php echo $row->payment_id ?></th>
                        <td><?php echo $row->customer_id ?></td>
                        <td><?php echo $row->staff_id ?></td>
                        <td><?php echo $row->rental_id ?></td>
                        <td><?php echo $row->amount ?></td>
                        <td><?php echo $row->payment_date ?></td>
                        <td><?php echo $row->last_update ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

    </main>

    <?php include('includes/footer.php'); ?>
