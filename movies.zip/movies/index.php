<?php $currentPage = 'Home'; ?>
<?php include('includes/head.php'); ?>

<body class="d-flex flex-column h-100">

    <?php include('includes/navbar.php'); ?>

    <main class="flex-shrink-0">
        <div class="container rounded bg-light p-3" style="margin-top: 5em">
            <h1 class="display-3">Welcome!</h1>
            <p class="lead">This is the management site for the Fantastic Movies database.</p>
            <hr class="my-4">
            <p>You can browse each table by selecting one from the button located at the top of each page. Or go to the first table below:</p>
            <p class="lead"><a class="btn btn-primary btn-lg" href="actor.php" role="button">Go to "actor"</a></p>
        </div>
    </main>

    <?php include('includes/footer.php'); ?>
