<footer class="footer mt-auto py-3 bg-light">
    <div class="container">
        <span class="text-muted">&copy; 2021, Fantastic Tea (Group 32).</span>
    </div>
</footer>


<script src="js/bootstrap.bundle.min.js"></script>


</body>

</html>
