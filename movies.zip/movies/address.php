<?php include('server.php'); ?>
<?php $currentPage = 'Address'; ?>
<?php include('includes/head.php'); ?>

<?php
$conn = mysqli_connect("localhost", "root", "", "exercise");
if (isset($_POST['search'])) {
    $searchKey = $_POST['searchkey'];
    if ($searchKey >= 1) {
        $sql = "SELECT * FROM `address` WHERE address_id = $searchKey";
        $result = mysqli_query($conn, $sql);
    }

    if ($searchKey == 0 || $searchKey == "") {
        $sql = "SELECT * FROM `address`";
        $result = mysqli_query($conn, $sql);
    }
} else {
    //$searchKey = $_POST['searchkey'];
    //if ($searchKey == 0 || $searchKey == "") {
    $sql = "SELECT * FROM `address` LIMIT 750";
    $result = mysqli_query($conn, $sql);
    //}
}
?>

<body class="d-flex flex-column h-100">

    <?php include('includes/navbar.php'); ?>

    <main class="flex-shrink-0">
        <div class="container-sm rounded bg-light p-3" style="margin-top: 5em">
            <div class="row g-3 justify-content-between align-items-center">
                <div class="col">
                    <button class="btn btn-primary me-2" type="button" data-bs-toggle="collapse" data-bs-target="#insertUpdateAddress" aria-expanded="false" aria-controls="insertUpdateAddress">Insert/update entry</button>
                    <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#deleteAddressID" aria-expanded="false" aria-controls="deleteAddressID">Delete entry</button>
                </div>
                <form class="col-lg-3 col-md-5" action="" method="POST">
                    <div class="input-group">
                        <input type="number" class="form-control" name="searchkey" id="searchkey" placeholder="Address ID" aria-describedby="searchBtn" min="1">
                        <button type="submit" class="btn btn-outline-primary" name="search" id="searchBtn" type="button" id="searchBtn">Search</button>
                    </div>
                </form>
            </div>

            <form class="collapse" id="insertUpdateAddress" action="server.php" method="POST">
                <hr>
                <h5 class="mt-3 mb-3">Insert/update entry in <strong><?= $currentPage ?></strong>:</h5>
                <div class="row g-3">
                    <div class="col form-floating mb-3">
                        <input type="number" class="form-control" name="addressidAddress" id="addressidAddress" min="1" placeholder="1" required>
                        <label for="addressidAddress">&ensp;Address ID</label>
                    </div>

                    <div class="col form-floating mb-3">
                        <input type="number" class="form-control" name="cityidAddress" id="cityidAddress" min="1" placeholder="1" required>
                        <label for="cityidAddress">&ensp;City ID</label>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col form-floating mb-3">
                        <input type="text" class="form-control" name="addressAddress" id="addressAddress" placeholder="a" required>
                        <label for="addressAddress">&ensp;Address</label>
                    </div>

                    <div class="col form-floating mb-3">
                        <input type="text" class="form-control" name="address2Address" id="address2Address" placeholder="a" required>
                        <label for="address2Address">&ensp;Address 2</label>
                    </div>

                    <div class="col form-floating mb-3">
                        <input type="text" class="form-control" name="postalcodeAddress" id="postalcodeAddress" placeholder="a" required>
                        <label for="postalcodeAddress">&ensp;Postal Code</label>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col form-floating mb-3">
                        <input type="text" class="form-control" name="districtAddress" id="districtAddress" placeholder="a" required>
                        <label for="districtAddress">&ensp;District</label>
                    </div>

                    <div class="col form-floating mb-3">
                        <input type="tel" class="form-control" name="phoneAddress" id="phoneAddress" min="1" placeholder="1" required>
                        <label for="phoneAddress">&ensp;Phone Number</label>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary" name="insertAddress">Submit</button>
            </form>

            <form class="collapse" id="deleteAddressID" action="server.php" method="POST">
                <hr>
                <h5 class="mt-3 mb-3">Delete entry from <strong><?= $currentPage ?></strong>:</h5>
                <div class="row g-3">
                    <div class="col form-floating mb-3">
                        <input type="number" class="form-control" name="addressidAddress" id="addressidAddress" min="1" placeholder="1" required>
                        <label for="addressidAddress">&ensp;Address ID</label>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary" name="deleteAddress">Submit</button>
            </form>
        </div>

        <table class="table table-striped table-hover table-responsive caption-top container-sm p-3 mt-3">
            <caption>
                <h3 class="text-primary">Entries in <strong><?= $currentPage ?></strong>:</h3>
            </caption>
            <thead>
                <tr>
                    <th scope="col">Address ID &ensp;<span class="material-icons align-bottom me-2 text-warning">vpn_key</span></th>
                    <th scope="col">Address</th>
                    <th scope="col">Address 2</th>
                    <th scope="col">District</th>
                    <th scope="col">City ID &ensp;<span class="material-icons align-bottom me-2 text-muted">vpn_key</span></th>
                    <th scope="col">Postal Code</th>
                    <th scope="col">Phone Number</th>
                    <th scope="col">Last Updated</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_object($result)) : ?>
                    <tr>
                        <th scope="row"><?php echo $row->address_id ?></th>
                        <td><?php echo $row->address ?></td>
                        <td><?php echo $row->address2 ?></td>
                        <td><?php echo $row->district ?></td>
                        <td><?php echo $row->city_id ?></td>
                        <td><?php echo $row->postal_code ?></td>
                        <td><?php echo $row->phone ?></td>
                        <td><?php echo $row->last_update ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

    </main>

    <?php include('includes/footer.php'); ?>
