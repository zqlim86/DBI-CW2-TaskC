<?php $currentPage = 'Login'; ?>
<?php include('includes/head.php'); ?>

<body class="d-flex flex-column h-100">

    <?php include('includes/navbar.php'); ?>

    <main class="flex-shrink-0">
        <div class="container rounded bg-light p-3" style="margin-top: 5em; max-width: 27rem;">
            <form>
                <h4><span class="material-icons">lock</span></h4>
                <h1 class="h3 mb-3 fw-normal">Please login:</h1>

                <div class="form-floating">
                    <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
                    <label for="floatingInput">Email address</label>
                </div>
                <div class="form-floating">
                    <input type="password" class="form-control" id="floatingPassword" placeholder="Password">
                    <label for="floatingPassword">Password</label>
                </div>

                <div class="checkbox mb-3">
                    <label>
                        <input type="checkbox" value="remember-me"> Remember me
                    </label>
                </div>
                <button class="w-100 btn btn-lg btn-primary" type="submit">Login</button>
            </form>
        </div>
    </main>

    <?php include('includes/footer.php'); ?>
